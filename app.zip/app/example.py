import main
print(main.data)